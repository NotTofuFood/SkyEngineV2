package renderer;

import java.awt.Graphics2D;

public class GUIRenderer extends Renderer {

	private static final long serialVersionUID = -2325402669613015668L;

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void render(Graphics2D g) {
		//g.setColor(c);
	}

	@Override
	public int getFOV() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isUp() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setUp(boolean up) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isDown() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setDown(boolean down) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isLeft() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setLeft(boolean left) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isRight() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void setRight(boolean right) {
		// TODO Auto-generated method stub
		
	}

}
