package gui;

public enum ParametersValues {
	VAL_INF, VAL_NEG, VAL_POS, GUI_POS, GUI_TEXT, GUI_IMAGE, GUI_INFO
}